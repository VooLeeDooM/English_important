let themeBtn = document.querySelector('.theme_btn');

themeBtn.addEventListener('click', function() {
  let body = document.querySelector('body');
  body.toggleAttribute('dark');
});